package main

import "fmt"

func main() {
	var name string = "kk"

	fmt.Println(name)

	name = "silence" // 更新变量的值(赋值)
	fmt.Println(name)
}
