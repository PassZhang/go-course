package main

import "fmt"

func main() {
	fmt.Println("start")
	goto END

	fmt.Println("1")
END:
	fmt.Println("end")
}
