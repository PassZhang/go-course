package main

import "fmt"

func main() {
	for true {
		fmt.Printf("这是无限循环。\n")
	}
}
