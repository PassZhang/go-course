# Golang第四周笔记
包管理和使用
go语言中的单元测试和常用模块




上课代码文件创建的顺序
1. 上节课作业：hw01.go
2. tudolist 文件夹 go mod init tudolist
   1. models 文件夹
      1. task.go
   2. controllers
      1. task.go
   3. main.go
3. web 文件夹
   1. main.go
4. strutil 文件夹
   1. rand.go
5. testcmd 文件夹
   1. main.go
6. testflag 文件夹
   1. main.go
7. testflagv2 文件夹
   1. main.go
8. testlog
   1. main.go
9. 




github.com/passzhang/仓库名称(项目名称)


git@github.com:PassZhang/strutil.git

github.com/passzhang/strutil


参数解析： os.args、flag 