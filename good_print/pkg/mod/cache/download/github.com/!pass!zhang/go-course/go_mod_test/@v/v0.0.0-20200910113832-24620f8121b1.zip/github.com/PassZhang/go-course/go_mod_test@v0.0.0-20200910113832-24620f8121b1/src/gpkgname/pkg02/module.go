package pkg02

var Name string = "good print pkg02"
