// for 子语句可以只保留条件子语句，此时类似于其他语言中的while循环。

package main

func main() {
	sum = 0
	i := 1
	for i <= 100 {
		sum += i
		i++
	}
}
