# Golang第三周笔记
函数内容



上课代码文件创建的顺序
1. func.go
2. params.go
3. args.go
4. return.go
5. quote.go
6. returnvalue.go
7. fact.go
8. tower.go
9. pointer.go  必须理解
10. type.go
11. funcparams.go
12. lambda.go
13. lambda2.go
14. block.go
15. closer.go
16. sort.go

建立目录 todolist
    1. tudolist.go
    2. add.go
    3. query.go
    4. tudolist_v2.go
17. error.go
18. errors.go
19. defer.go
20. forerror.go
21. panic.go
22. 

建立目录 main
    1. main.go
    2. utils.go   // 关闭GO111MODULE=off, go build
    3. 

23. readme.md




