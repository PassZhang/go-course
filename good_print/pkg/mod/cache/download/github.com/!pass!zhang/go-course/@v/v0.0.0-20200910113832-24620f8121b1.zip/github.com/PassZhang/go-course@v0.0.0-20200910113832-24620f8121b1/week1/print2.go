package main

import "fmt"

func main() {
	fmt.Printf("[%3d]\n", 1)
	fmt.Printf("[%03d]\n", 10000)
	fmt.Printf("[%03d]\n", 1)
}
