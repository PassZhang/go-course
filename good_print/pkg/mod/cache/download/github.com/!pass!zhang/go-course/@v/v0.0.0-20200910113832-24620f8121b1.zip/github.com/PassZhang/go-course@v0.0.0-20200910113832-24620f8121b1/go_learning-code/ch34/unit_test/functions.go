package testing

func square(op int) int {
	return op * op
}
