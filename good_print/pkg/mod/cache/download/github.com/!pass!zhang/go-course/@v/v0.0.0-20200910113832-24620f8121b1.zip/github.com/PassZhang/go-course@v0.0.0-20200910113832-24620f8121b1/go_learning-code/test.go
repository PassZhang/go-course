package try_test

import "testing"

func TestFirstTry(t *testing.T) {
	t.Log("My first try!")
}
