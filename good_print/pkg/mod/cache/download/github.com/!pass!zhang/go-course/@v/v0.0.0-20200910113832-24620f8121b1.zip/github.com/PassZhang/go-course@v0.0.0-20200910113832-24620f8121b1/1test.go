package main

import . "fmt"


func main()  {
	println("Hello World")
}