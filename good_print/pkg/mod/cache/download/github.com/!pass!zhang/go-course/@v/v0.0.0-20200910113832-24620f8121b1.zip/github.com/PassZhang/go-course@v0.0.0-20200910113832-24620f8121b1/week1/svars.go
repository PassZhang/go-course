package main

import "fmt"

func main() {
	n1, n2 := 1, 2
	fmt.Println(n1, n2)

	n3, n4 := 3, 4
	fmt.Println(n3, n4)
}
