package main

import "fmt"

func main() {
	var a string = "Runoob"
	fmt.Println(a)

	var b,c int = 1,2
	fmt.Println(b,c)
}


