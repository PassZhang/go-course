package main

import "fmt"

func main() {
	var index = 1
	for index <= 10 {
		fmt.Println(index)
		index++
	}
}
