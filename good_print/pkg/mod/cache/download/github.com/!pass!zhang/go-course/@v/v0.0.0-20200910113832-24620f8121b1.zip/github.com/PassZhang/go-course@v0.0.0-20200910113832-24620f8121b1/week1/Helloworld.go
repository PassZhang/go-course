// 定义包main
package main

// 导入标准包fmt
import "fmt"

// 程序入口，main函数
func main() {
	/*
		这里是一个注释
		这里是调用fmt包下的println函数打印内容到控制台
	*/
	fmt.Println("Hello World!") // 打印hello world 到控制台
}
