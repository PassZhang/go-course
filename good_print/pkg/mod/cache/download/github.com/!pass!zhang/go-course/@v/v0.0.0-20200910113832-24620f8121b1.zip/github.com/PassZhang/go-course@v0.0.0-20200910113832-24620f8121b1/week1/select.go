// select 是 Go 中的一个控制结构，类似于用于通信的 switch 语句。每个 case 必须是一个通信操作，要么是发送要么是接收。

// select 随机执行一个可运行的 case。如果没有 case 可运行，它将阻塞，直到有 case 可运行。一个默认的子句应该总是可运行的。

/*
select {
    case communication clause  :
       statement(s);
    case communication clause  :
       statement(s);
   // 你可以定义任意数量的 case
	default : // 可选
       statement(s);
}
*/

package main

import "fmt"

func main() {
	var c1, c2, c3 chan int
	var i1, i2 int
	select {
	case i1 = <-c1:
		fmt.Printf("received", i1, "from c1\n")
	case c2 <- i2:
		fmt.Printf("sent", i2, "to c2\n")
	case i3, ok := (<-c3): //same as i3,ok := <=c3
		if ok {
			fmt.Printf("received", i3, "from c3\n")
		} else {
			fmt.Printf("c3 is closed\n")
		}
	default:
		fmt.Printf("no communication\n")
	}
}
