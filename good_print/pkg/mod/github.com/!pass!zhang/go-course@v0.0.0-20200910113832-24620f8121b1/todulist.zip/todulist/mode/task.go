package mode

import (
	"encoding/json"
	"errors"
	"io/ioutil"
	"os"
)

type Task struct {
	Id       int    `json:"id"`
	Name     string `json:"name"`
	Progress int    `json:"progress"`
	User     string `json:"user"`
	Desc     string `json:"desc"`
	Status   string `json:"staus"`
}


//读取
func loadTasks() ([]Task,error){
	//读取数据文件
	if bytes,err := ioutil.ReadFile("datas/tasks.json");err != nil {
		//如果是文件不存在  返回空数据 err返回nil
		if os.IsNotExist(err){
			return []Task{} ,nil
		}else {
			//如果是报错 返回nil 并且返回报错
			return nil,err
		}
	}else{
		var tasks []Task
		//反序列化从json中读取到内存中
		if err := json.Unmarshal(bytes,&tasks);err == nil {
			return  tasks,nil
		}else {
			return nil,err
		}
	}
}




func storeTasks(tasks []Task) error {
	bytes,err := json.MarshalIndent(tasks,"","\t")
	if err != nil {
		return err
	}
	//将数据写入文件
	return ioutil.WriteFile("datas/tasks.json",bytes,0X066)
}

//读取tasks
func GetTasks() []Task {
	tasks,err := loadTasks()
	if err == nil {
		return tasks
	}
	panic(err)
}

//task是[]切片 所以修改之后append添加
func CreateTask(name,user,desc string) {
	id,err := GetID()
	if err != nil {
		panic(err)
	}
	task := Task{
		Id:       id,
		Name:     name,
		Progress: 0,
		User:     user,
		Desc:     desc,
		Status:   "new" ,
	}
	tasks,err := loadTasks()
	if err != nil {
		panic(err)
	}
	tasks = append(tasks,task)
	storeTasks(tasks)
}

func GetID() (int,error){
	var id int = 0
	tasks ,err:= loadTasks()
	if err != nil {
		return -1,err
	}
	for _,v := range tasks{
		if id < v.Id{
			id = v.Id
		}
	}
	return id+1 ,nil
}


func GetTaskID(id int) (Task,error){
	tasks,err :=loadTasks()
	if err == nil {
		for _,task := range tasks{
			if task.Id == id {
				return  task,nil
			}
		}
	}else {
		panic(err)
	}
	return Task{}, errors.New("Not Found")
}

func ChangeTasks(progress,id int,name,desc ,user,status string) {
	tasks,err := loadTasks()
	if err == nil {
		for k,task := range tasks{
			if task.Id == id {
				task.Name = name
				task.Status = status
				task.User = user
				task.Progress = progress
				task.Desc = desc
			}
			tasks[k] = task
		}
		storeTasks(tasks)
	}else {
		panic(err)
	}
}


func DeleteTask(id int){
	tasks,err := loadTasks()
	if err != nil {
		panic(err)
	}
	for k,task := range tasks{
		if task.Id == id{
			tasks = append(tasks[:k],tasks[k+1:]...)
		}
	}
	storeTasks(tasks)
	//newtasks := []Task{}
	//for _,task := range tasks{
	//	if task.Id != id {
	//		newtasks = append(newtasks,task)
	//	}
	//}
	//storeTasks(newtasks)
}