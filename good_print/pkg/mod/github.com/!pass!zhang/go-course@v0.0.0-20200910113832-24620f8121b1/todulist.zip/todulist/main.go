package main

import (
	"net/http"
	//_ "todolist/controliers"
	_ "todolist/users/controliers"
)
func main() {
	addr := "0.0.0.0:9999"
	http.ListenAndServe(addr,nil)
}
