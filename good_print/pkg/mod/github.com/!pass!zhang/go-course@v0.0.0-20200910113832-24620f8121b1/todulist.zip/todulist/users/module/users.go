package module

import (
	"encoding/json"
	"io/ioutil"
	"os"
	"time"
)

type User struct {
	Id  int `json:"id"`
	Name string `json:"name"`
	Birthday time.Time `json:"birthday"`
	Tel string `json:"tel"`
	Addr string `json:"addr"`
	Desc string `json:"desc"`
	Password string `json:"password"`
}

func loaduser() (map[int]User,error){
	bytes ,err := ioutil.ReadFile("users/data/user.json")
	if err != nil {
		if os.IsNotExist(err){
			return map[int]User{},nil
		}else {
			return nil,err
		}
	}else {
		var users map[int]User
		//将字节切片的反序列化出来
		if err = json.Unmarshal(bytes,&users);err==nil {
			return users,nil
		}else {
			return  nil,err
		}
	}
}

func Saveuser(users map[int]User,) error{
	//将数据json序列化
	bytes,err:=json.MarshalIndent(users,"","\t")
	if err != nil {
		return  err
	}
	//因为这里writefile会返回一个error  可以直接返回 写入成功就是nil 否则就会返回一个报错
	return ioutil.WriteFile("users/data/user.json",bytes,0X066)
}

func GetUser() map[int]User{
	users ,err:= loaduser()
	if err != nil {
		panic(err)
	}
	return users
}

func GetID() (int,error) {
	var id int = 0
	users,err  := loaduser()
	if err != nil {
		return -1,err
	}
	for k,_  := range users{
		if id <k {
			id = k
		}
	}
	return id+1,nil
}

func AppendUsers(name string,birthday time.Time,tel,addr,desc,password string) {
	id,err := GetID()
	if err != nil {
		panic(err)
	}
	users ,err := loaduser()
	if err != nil {
		panic(err)
	}
	users[id] = User{
		Id:       id,
		Name:     name,
		Birthday: birthday,
		Tel:      tel,
		Addr:     addr,
		Desc:     desc,
		Password: password,
	}
	err = Saveuser(users)
	if err != nil {
		panic(err)
	}
}

func ChangeUser(id int,name string,birthday time.Time,tel,addr,desc string) {
	users := GetUser()
	password := users[id].Password
	user := User{
		Id:       id,
		Name:     name,
		Birthday: birthday,
		Tel:      tel,
		Addr:     addr,
		Desc:     desc,
		Password: password,
	}
	users[id] = user
	Saveuser(users)
}

func Account(name ,password string) bool {
	users := GetUser()
	//遍历映射
	for _,user := range users {
		//找到对应的用户
		if  name == user.Name {
			//判断密码是否相同 如果相同返回true
			if password == user.Password{
				return  true
			}else {
				//如果用户i相同  密码不同  返回密码错误
				return  false
			}
		}
	}
	return false
}