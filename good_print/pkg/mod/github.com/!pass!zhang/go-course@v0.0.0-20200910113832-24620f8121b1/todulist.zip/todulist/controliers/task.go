package controliers

import (
	"fmt"
	"html/template"
	"net/http"
	"strconv"
	"todolist/mode"
)

func TaskAction(w http.ResponseWriter,r *http.Request) {
	//must表示如果这个函数内err不是nil那么直接panic
	tpl := template.Must(template.New("task.html").ParseFiles("views/task.html"))
	tpl.Execute(w,mode.GetTasks())
}


func TaskCreateAction(w http.ResponseWriter,r *http.Request) {
	if r.Method == http.MethodGet {
		tpl := template.Must(template.New("create_task.html").ParseFiles("views/create_task.html"))
		tpl.Execute(w,nil)
	}else if r.Method == http.MethodPost {
		fmt.Println("a")
		//从浏览器获取用户输入的数据
		name := r.PostFormValue("name")
		user := r.PostFormValue("user")
		desc := r.PostFormValue("desc")
		//调用create来创建
		mode.CreateTask(name,user,desc)
		//创建完之后重定向到初始目录
		http.Redirect(w,r,"/",http.StatusFound)
	}else {
		w.WriteHeader(http.StatusMethodNotAllowed)
	}
}

func TaskChangeAction(w http.ResponseWriter,r *http.Request) {
	if r.Method == http.MethodGet {
		id ,err :=  strconv.Atoi(r.FormValue("id"))
		if err == nil {
			task,err := mode.GetTaskID(id)
			if err ==nil {
				tpl := template.Must(template.New("change_task.html").ParseFiles("views/change_task.html"))
				tpl.Execute(w,task)
			}else {
				w.WriteHeader(http.StatusBadRequest)
			}
		}else {
			//如果id不存在 报错400
			w.WriteHeader(http.StatusBadRequest)
		}
	}else if r.Method == http.MethodPost {
		id ,err :=  strconv.Atoi(r.PostFormValue("id"))
		if err == nil {
			name := r.PostFormValue("name")
			desc := r.PostFormValue("desc")
			progress, err := strconv.Atoi(r.PostFormValue("progress"))
			if err != nil {
				w.WriteHeader(http.StatusBadRequest)
			}
			user := r.PostFormValue("user")
			status := r.PostFormValue("status")
			mode.ChangeTasks(progress,id,name,desc,user,status)
		}else {
			w.WriteHeader(http.StatusBadRequest)
		}
		//创建完之后重定向到初始目录
		//这里用302临时重定向  如果用301有缓存会导致 无法删除 缓存在直接从缓存拿
		http.Redirect(w,r,"/",http.StatusFound)
	}else {
		w.WriteHeader(http.StatusMethodNotAllowed)
	}
}

func TaskDeleteAction(w http.ResponseWriter,r *http.Request) {
	id ,err :=  strconv.Atoi(r.FormValue("id"))
	if err != nil {
		w.WriteHeader(http.StatusBadRequest)
	}
	mode.DeleteTask(id)
	http.Redirect(w,r,"/",http.StatusFound)
}



func init() {
	http.HandleFunc("/",TaskAction)
	http.HandleFunc("/tasks/create/",TaskCreateAction)
	http.HandleFunc("/tasks/change/",TaskChangeAction)
	http.HandleFunc("/tasks/delete/",TaskDeleteAction)
}
