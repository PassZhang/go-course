package controliers

import (
	"crypto/md5"
	"fmt"
	"html/template"
	"net/http"
	"strconv"
	"time"
	"todolist/users/module"
)

func GetUsers(w http.ResponseWriter,r *http.Request) {
	//这里要注意路径问题 这个当前路径是以main.go的当前路径
	tpl := template.Must(template.New("users.html").ParseFiles("users/views/users.html"))
	tpl.Execute(w,module.GetUser())
}

func CreateUsers(w http.ResponseWriter,r *http.Request) {
	if r.Method == http.MethodGet{
	tpl := template.Must(template.New("create_user.html").ParseFiles("users/views/create_user.html"))
	tpl.Execute(w,nil)
	}else if r.Method == http.MethodPost {
		addr := r.PostFormValue("addr")
		fmt.Println(r.PostFormValue("birthday"))
		birthday,_ := time.Parse("2006-01-02",r.PostFormValue("birthday"))
		fmt.Println(birthday)
		desc := r.PostFormValue("desc")
		name := r.PostFormValue("name")
		password := fmt.Sprintf("%x",md5.Sum([]byte(r.PostFormValue("password"))))
		tel := r.PostFormValue("tel")
		module.AppendUsers(name,birthday,tel,addr,desc,password)
		http.Redirect(w,r,"/user",http.StatusFound)
	}else {
		w.WriteHeader(http.StatusMethodNotAllowed)
	}
}

func ChangeUser(w http.ResponseWriter,r *http.Request) {
	if r.Method == http.MethodGet{
		id , err := strconv.Atoi(r.FormValue("id"))
		if err != nil {
			w.WriteHeader(http.StatusBadRequest)
		}
		users := module.GetUser()
		tpl := template.Must(template.New("change_user.html").ParseFiles("users/views/change_user.html"))
		tpl.Execute(w,users[id])
	}else if r.Method == http.MethodPost {
		id , err := strconv.Atoi(r.FormValue("id"))
		if err != nil {
			w.WriteHeader(http.StatusBadRequest)
		}
		addr := r.PostFormValue("addr")
		birthday,_ := time.Parse("2006-01-02",r.PostFormValue("birthday"))
		desc := r.PostFormValue("desc")
		name := r.PostFormValue("name")
		tel := r.PostFormValue("tel")
		module.ChangeUser(id,name,birthday,tel,addr,desc)
		http.Redirect(w,r,"/user",http.StatusFound)
	}else {
		w.WriteHeader(http.StatusMethodNotAllowed)
	}
}

func DeleteUser(w http.ResponseWriter,r *http.Request) {
	id , err := strconv.Atoi(r.FormValue("id"))
	if err != nil {
		w.WriteHeader(http.StatusBadRequest)
	}
	users := module.GetUser()
	delete(users,id)
	module.Saveuser(users)
	http.Redirect(w,r,"/user",http.StatusFound)
}


func Login(w http.ResponseWriter,r *http.Request) {
	if r.Method ==   http.MethodGet{
		tpl := template.Must(template.New("passworld.html").ParseFiles("users/views/passworld.html"))
		tpl.Execute(w,nil)
	}else if r.Method == http.MethodPost {
		username := r.PostFormValue("username")
		password := fmt.Sprintf("%x",md5.Sum([]byte(r.PostFormValue("password"))))
		if Verify:= module.Account(username,password);Verify{
			http.Redirect(w,r,"/user/",http.StatusFound)
		}else {
			http.Redirect(w,r,"/",http.StatusBadRequest)
			w.Write([]byte("登陆失败请重新登录"))
		}
	}else {
		w.WriteHeader(http.StatusBadRequest)
	}
}
func init() {
	http.HandleFunc("/",Login)
	http.HandleFunc("/user/",GetUsers)
	//全路径 /xxx/
	http.HandleFunc("/user/create/",CreateUsers)
	http.HandleFunc("/user/change/",ChangeUser)
	http.HandleFunc("/user/delete/",DeleteUser)
}